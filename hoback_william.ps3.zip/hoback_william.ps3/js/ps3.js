/* ps3.js */
// #1 create object that has 3 props and 1 method which does something useful.
//your code goes here

//Part 1
var character = {};
	character.firstName = "Sherlock";
	character.lastName = "Holmes";
	character.age = 45;
	character.meth = function () {
		var a = "This character is " + character.firstName + " " + character.lastName + " " + "and he is " + character.age + " years old."
		var b = document.getElementById('answer')
		b.innerHTML = a
	}

//Part 2
function two (obj, string) {
	console.log( obj[string] )
}

two(character, "age");